# Hybrid Inventory Manager

A console-based inventory CRUD application demonstrating a **hybrid C / C++ architecture**:

- **C layer** — binary file I/O (`fread` / `fwrite` / `fseek`) for persistent record storage
- **C++ layer** — `InventoryManager` class, `std::vector`, `std::sort`, interactive menu, input validation

All data persists across program restarts through a fixed-size binary file (`inventory.dat`).

---

## File Structure

```
HybridInventoryManager/
├── include/
│   ├── inventory.h          # Item struct + C function prototypes
│   └── InventoryManager.h   # C++ class declaration
├── src/
│   ├── inventory.c          # C backend — binary file storage
│   ├── InventoryManager.cpp # C++ class — STL vector/sort, search, display
│   └── main.cpp             # Menu, input validation, entry point
├── Makefile
└── README.md
```

---

## Build & Run

**Requirements:** `gcc`, `g++`, `make`

```bash
cd HybridInventoryManager

make          # compiles everything into ./inventory_manager
make run      # build + launch immediately
make clean    # remove build artefacts and inventory.dat
```

The Makefile compiles `.c` files with `gcc -std=c11` and `.cpp` files with `g++ -std=c++17`, then links with `g++`.

---

## Features

### Core CRUD
| Option | Action |
|--------|--------|
| 1 | Add item (unique ID, name, quantity, price) |
| 2 | View item by ID |
| 3 | Update item (shows current values first) |
| 4 | Delete item (soft delete — record stays in file, hidden from views) |
| 5 | List all active items |

### Extra Features
| Option | Action |
|--------|--------|
| 5 | List with sort: by ID / Name / Price |
| 6 | Search active items by name (case-insensitive substring) |

### Input Validation
- ID must be a positive integer — re-prompted on invalid input
- Quantity must be 0 or more — re-prompted on invalid input
- Price must be 0.00 or more — re-prompted on invalid input
- Name must not be empty — re-prompted on invalid input
- Application never crashes on bad input

---

## Architecture Notes

### C Backend (`inventory.c`)
- Uses `fopen`/`fclose` with binary modes (`rb`, `ab`, `r+b`)
- `find_record()` helper scans file for a matching ID and returns its byte offset
- `update_item` and `delete_item` use `fseek` to overwrite the exact record in-place
- `add_item` rejects duplicate IDs (including soft-deleted ones) to keep the file consistent
- `list_items` copies only active (`is_deleted == 0`) records into the caller's buffer

### C++ Layer (`InventoryManager.cpp`)
- `listAll()` uses `std::vector` to hold the active snapshot and `std::sort` with three lambda comparators (ID / Name / Price)
- `searchByName()` uses `std::transform` for case-insensitive matching, then `std::sort` before display
- All C functions are called through `extern "C"` linkage declared in `inventory.h`

---

## Test Cases

- **Persistence across restarts**
  Added items: ID 1 (Laptop, qty 5, $799.99), ID 2 (Mouse, qty 20, $15.50), ID 3 (Keyboard, qty 10, $45.00).
  Chose Exit, re-launched the program, selected List all — all three items appeared correctly sorted by ID.

- **Duplicate ID rejection**
  Attempted to add a second item with ID 1 while ID 1 (Laptop) already existed.
  The app printed `[Error] Could not add — duplicate ID` and returned to the menu without corrupting the file.

- **Update persists after restart**
  Updated item 2 (Mouse) — changed quantity to 50 and price to $12.99.
  Chose Exit, re-launched, viewed item 2 — new values (qty 50, $12.99) were displayed correctly.

- **Soft delete hides item**
  Deleted item 3 (Keyboard). Selected List all — only items 1 and 2 appeared.
  Selected View item with ID 3 — received `[Error] Item not found or has been deleted`.
  The binary file still contains the record with `is_deleted = 1`.

- **Input validation loops**
  Entered `-3` for ID → re-prompted with `[!] Must be a positive integer`.
  Pressed Enter on empty name → re-prompted with `[!] Name must not be empty`.
  Entered `-9.99` for price → re-prompted with `[!] Must be 0.00 or more`.
  Application remained stable throughout; all corrections were accepted on retry.

- **Search by name**
  With items Laptop, Mouse, Keyboard active — searched for keyword `key`.
  Result showed only Keyboard. Searched for `o` — returned Mouse and Keyboard (case-insensitive).

- **Sort options**
  Listed all items sorted by Price — Keyboard ($45.00) appeared before Laptop ($799.99).
  Listed sorted by Name — Keyboard, Laptop, Mouse in alphabetical order.
