#ifndef INVENTORY_MANAGER_H
#define INVENTORY_MANAGER_H

#include "inventory.h"

#include <string>
#include <vector>

/*
 * InventoryManager — C++ layer over the C backend.
 *
 * Uses:
 *   std::vector  — to hold a temporary snapshot of active items
 *   std::sort    — to sort that snapshot by ID, name, or price
 */
class InventoryManager {
public:
    /* CRUD — thin wrappers that call the C backend */
    bool addItem    (const Item &item);
    bool viewItem   (int id);
    bool updateItem (int id, const Item &updated);
    bool deleteItem (int id);

    /* List with sort options */
    enum class SortBy { ID, NAME, PRICE };
    void listAll(SortBy sort = SortBy::ID);

    /* Extra: search active items whose name contains a substring */
    void searchByName(const std::string &keyword);

private:
    static void printHeader();
    static void printRow   (const Item &it);
    static void printFooter();
};

#endif /* INVENTORY_MANAGER_H */
