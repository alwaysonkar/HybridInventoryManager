#include "InventoryManager.h"

#include <algorithm>
#include <cctype>
#include <iomanip>
#include <iostream>
#include <string>
#include <vector>

/* ------------------------------------------------------------------ */
/* Pretty-print helpers                                                 */
/* ------------------------------------------------------------------ */

void InventoryManager::printHeader()
{
    std::cout << "\n  "
              << std::left
              << std::setw(6)  << "ID"
              << std::setw(22) << "Name"
              << std::setw(10) << "Qty"
              << std::setw(12) << "Price"
              << "\n  " << std::string(50, '-') << "\n";
}

void InventoryManager::printRow(const Item &it)
{
    std::cout << "  "
              << std::left
              << std::setw(6)  << it.id
              << std::setw(22) << it.name
              << std::setw(10) << it.quantity
              << "$" << std::fixed << std::setprecision(2) << it.price
              << "\n";
}

void InventoryManager::printFooter()
{
    std::cout << "  " << std::string(50, '-') << "\n";
}

/* ------------------------------------------------------------------ */
/* CRUD wrappers                                                        */
/* ------------------------------------------------------------------ */

bool InventoryManager::addItem(const Item &item)
{
    if (add_item(&item)) return true;
    std::cerr << "  [Error] Could not add — duplicate ID or write failure.\n";
    return false;
}

bool InventoryManager::viewItem(int id)
{
    Item out{};
    if (get_item(id, &out)) {
        printHeader();
        printRow(out);
        printFooter();
        return true;
    }
    std::cerr << "  [Error] Item not found or has been deleted.\n";
    return false;
}

bool InventoryManager::updateItem(int id, const Item &updated)
{
    if (update_item(id, &updated)) return true;
    std::cerr << "  [Error] Could not update — item not found or deleted.\n";
    return false;
}

bool InventoryManager::deleteItem(int id)
{
    if (delete_item(id)) return true;
    std::cerr << "  [Error] Could not delete — item not found or already deleted.\n";
    return false;
}

/* ------------------------------------------------------------------ */
/* List with STL sort                                                   */
/* ------------------------------------------------------------------ */

void InventoryManager::listAll(SortBy sort)
{
    const int MAX = 1024;
    std::vector<Item> items(MAX);

    int count = list_items(items.data(), MAX);
    items.resize(static_cast<size_t>(count));

    if (items.empty()) {
        std::cout << "  (No active items in inventory.)\n";
        return;
    }

    /* std::sort with three different comparators */
    switch (sort) {
        case SortBy::NAME:
            std::sort(items.begin(), items.end(),
                      [](const Item &a, const Item &b) {
                          return std::string(a.name) < std::string(b.name);
                      });
            break;
        case SortBy::PRICE:
            std::sort(items.begin(), items.end(),
                      [](const Item &a, const Item &b) {
                          return a.price < b.price;
                      });
            break;
        case SortBy::ID:
        default:
            std::sort(items.begin(), items.end(),
                      [](const Item &a, const Item &b) {
                          return a.id < b.id;
                      });
            break;
    }

    printHeader();
    for (const auto &it : items) printRow(it);
    printFooter();
    std::cout << "  " << count << " active item(s).\n";
}

/* ------------------------------------------------------------------ */
/* Search by name (case-insensitive substring match)                   */
/* ------------------------------------------------------------------ */

void InventoryManager::searchByName(const std::string &keyword)
{
    const int MAX = 1024;
    std::vector<Item> items(MAX);

    int count = list_items(items.data(), MAX);
    items.resize(static_cast<size_t>(count));

    /* Convert keyword to lowercase for case-insensitive compare */
    std::string kw = keyword;
    std::transform(kw.begin(), kw.end(), kw.begin(),
                   [](unsigned char c) { return std::tolower(c); });

    std::vector<Item> results;
    for (const auto &it : items) {
        std::string n = it.name;
        std::transform(n.begin(), n.end(), n.begin(),
                       [](unsigned char c) { return std::tolower(c); });
        if (n.find(kw) != std::string::npos)
            results.push_back(it);
    }

    if (results.empty()) {
        std::cout << "  No items matched \"" << keyword << "\".\n";
        return;
    }

    /* Sort results by ID before printing */
    std::sort(results.begin(), results.end(),
              [](const Item &a, const Item &b) { return a.id < b.id; });

    printHeader();
    for (const auto &it : results) printRow(it);
    printFooter();
    std::cout << "  " << results.size() << " match(es) for \""
              << keyword << "\".\n";
}
